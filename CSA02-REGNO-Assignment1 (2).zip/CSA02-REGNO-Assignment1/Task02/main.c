/* Task 02 - read and print data correctly with scanf / printf */
#include "billing.h"

int main(void)
{
    unsigned id, prev, curr;
    int line = 0, bad = 0;
    int r;

    printf("%-6s %-6s %-6s %-7s %s\n", "House", "Prev", "Curr", "Units", "Bill (Rs)");
    while ((r = scanf("%u %u %u", &id, &prev, &curr)) != EOF) {
        line++;
        int ch, junk = 0;
        if (r == 3) {                       /* anything but spaces left on the line? */
            while ((ch = getchar()) != '\n' && ch != EOF)
                if (ch != ' ' && ch != '\t' && ch != '\r')
                    junk = 1;
        }
        if (r != 3 || junk) {               /* invalid input such as letters */
            printf("Line %d: invalid input (scanf returned %d%s) - skipped\n",
                   line, r, junk ? ", trailing garbage" : "");
            if (r != 3)
                while ((ch = getchar()) != '\n' && ch != EOF)
                    ;                       /* discard rest of the bad line */
            bad++;
            continue;
        }
        if (prev > 65535u || curr > 65535u) {
            printf("Line %d: reading out of 16-bit meter range - skipped\n", line);
            bad++;
            continue;
        }
        long u = units_consumed(prev, curr);
        long b = compute_bill_paise(u);
        printf("%-6u %-6u %-6u %-7ld Rs ", id, prev, curr, u);
        print_rupees(b);
        printf("\n");
    }
    printf("Processed %d lines, %d invalid.\n", line, bad);

    printf("\nRupees/paise from integer paise: 16250 paise = Rs ");
    print_rupees(16250);
    printf("\n");
    return 0;
}
