/* scanf with %f into a double: wrong specifier on input (reads garbage bits) */
#include <stdio.h>
int main(void)
{
    double rate = 0.0;
    int ok = sscanf("4.5", "%f", (float *)&rate);   /* wrong: should be %lf */
    printf("sscanf returned %d, rate (read with %%f into double) = %f\n", ok, rate);
    ok = sscanf("4.5", "%lf", &rate);
    printf("sscanf returned %d, rate (read with %%lf)            = %f\n", ok, rate);
    return 0;
}
