/* Format specifier table and wrong-specifier test (gcc will warn on purpose) */
#include <stdio.h>
int main(void)
{
    int d = -42; unsigned u = 42u; long ld = 1234567L; long long lld = 9876543210LL;
    float f = 2.25f; double lf = 4.5; char c = 'R'; const char *s = "paise";
    long big = 5000000000L;

    printf("%%d  int:         %d\n", d);
    printf("%%u  unsigned:    %u\n", u);
    printf("%%ld long:        %ld\n", ld);
    printf("%%lld long long:  %lld\n", lld);
    printf("%%f  float/double:%f\n", f);
    printf("%%lf double:      %lf\n", lf);
    printf("%%c  char:        %c\n", c);
    printf("%%s  string:      %s\n", s);

    printf("\nCorrect  %%ld of 5000000000L : %ld\n", big);
    printf("WRONG    %%d  of 5000000000L : %d   <-- truncated to 32 bits\n", big);
    printf("WRONG    %%u  of -42         : %u   <-- sign lost\n", (unsigned)d);
    return 0;
}
