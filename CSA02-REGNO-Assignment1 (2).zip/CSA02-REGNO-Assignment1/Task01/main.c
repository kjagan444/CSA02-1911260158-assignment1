/* Task 01 - header file, include guards, conditional compilation (DEBUG) */
#include "billing.h"

int main(void)
{
    unsigned id, prev, curr;
    long total = 0;
    int n = 0;

    printf("House  Prev  Curr  Units   Bill (Rs)\n");
    while (scanf("%u %u %u", &id, &prev, &curr) == 3) {
        long u = units_consumed(prev, curr);
        long b = compute_bill_paise(u);
        DBG("house %u: prev=%u curr=%u -> units=%ld bill=%ld paise\n", id, prev, curr, u, b);
        printf("%5u %5u %5u %6ld   ", id, prev, curr, u);
        print_rupees(b);
        printf("\n");
        total += b;
        n++;
    }
    printf("Bills: %d   Total: Rs ", n);
    print_rupees(total);
    printf("\n");
    return 0;
}
