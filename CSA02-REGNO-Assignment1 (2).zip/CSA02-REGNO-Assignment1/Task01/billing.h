#ifndef BILLING_H
#define BILLING_H

#include <stdio.h>

/* ---- Tariff constants (ONE place, so a revision is never applied partly) ---- */
#define METER_MODULUS      65536L   /* 16-bit meter: 0..65535 then rolls to 0   */
#define FIXED_CHARGE_PAISE 5000L    /* Rs 50.00 fixed charge                    */
#define SLAB1_LIMIT        100L     /* first 100 units free                     */
#define SLAB2_LIMIT        200L     /* next 100 units at Rs 2.25                */
#define RATE2_PAISE        225L
#define RATE3_PAISE        450L     /* above 200 units at Rs 4.50               */

/* ---- Debug mode: compiled in only with gcc -DDEBUG ---- */
#ifdef DEBUG
#define DBG(...) fprintf(stderr, "[DEBUG] " __VA_ARGS__)
#else
#define DBG(...) ((void)0)
#endif

long units_consumed(unsigned prev, unsigned curr);  /* handles rollover      */
long compute_bill_paise(long units);                /* integer paise, exact  */
void print_rupees(long paise);                      /* prints e.g. 162.50    */

#endif /* BILLING_H */
