#include <stdio.h>
int main(void)
{
    long units = 150      /* missing semicolon -> COMPILE-TIME error */
    printf("%ld\n", units);
    return 0;
}
