#include <stdio.h>
int main(void)
{
    long paise = 16250;
    int count = 3;
    unsigned prev = 100;
    int unused;                        /* -Wall: unused variable      */
    printf("%d\n", paise);             /* -Wall: %d with long         */
    if (count < prev)                  /* -Wextra: signed/unsigned    */
        printf("less\n");
    return 0;
}
