#include <stdio.h>
int main(void)
{
    int bills = 0;
    long total = 16250;
    printf("Average bill = %ld\n", total / bills);   /* RUN-TIME error: division by zero */
    return 0;
}
