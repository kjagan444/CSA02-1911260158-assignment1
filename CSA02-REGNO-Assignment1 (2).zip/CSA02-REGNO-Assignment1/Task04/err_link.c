#include <stdio.h>
long compute_tax(long paise);           /* declared but never defined */
int main(void)
{
    printf("%ld\n", compute_tax(16250));   /* LINK-TIME error: undefined reference */
    return 0;
}
