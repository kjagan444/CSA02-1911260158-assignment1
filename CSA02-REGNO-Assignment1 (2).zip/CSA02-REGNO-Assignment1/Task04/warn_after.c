#include <stdio.h>
int main(void)
{
    long paise = 16250;
    unsigned count = 3;
    unsigned prev = 100;
    printf("%ld\n", paise);            /* %ld matches long            */
    if (count < prev)                  /* both unsigned               */
        printf("less\n");
    return 0;
}
