#include "billing.h"
void print_rupees(long paise) { printf("%ld.%02ld", paise / 100, paise % 100); }
