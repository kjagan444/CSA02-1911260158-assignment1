#include "billing.h"
long units_consumed(unsigned prev, unsigned curr)
{
    if (curr >= prev) return (long)(curr - prev);
    return (long)(METER_MODULUS - prev + curr);
}
long compute_bill_paise(long units)
{
    long energy = 0;
    if (units > SLAB2_LIMIT) {
        energy += (units - SLAB2_LIMIT) * RATE3_PAISE;
        energy += (SLAB2_LIMIT - SLAB1_LIMIT) * RATE2_PAISE;
    } else if (units > SLAB1_LIMIT) {
        energy += (units - SLAB1_LIMIT) * RATE2_PAISE;
    }
    return FIXED_CHARGE_PAISE + energy;
}
