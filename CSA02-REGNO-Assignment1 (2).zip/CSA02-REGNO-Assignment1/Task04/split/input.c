#include "billing.h"
int main(void)
{
    unsigned id, prev, curr; long total = 0;
    while (scanf("%u %u %u", &id, &prev, &curr) == 3) {
        long b = compute_bill_paise(units_consumed(prev, curr));
        printf("%u ", id); print_rupees(b); printf("\n"); total += b;
    }
    return 0;
}
