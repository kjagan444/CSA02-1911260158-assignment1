/* Error growth: float rupees vs exact integer paise, summed over n bills */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "billing.h"

int main(void)
{
    long ns[] = {1000, 10000, 100000, 1000000, 10000000};
    printf("%10s %16s %16s %14s\n", "n bills", "int total(paise)", "float total(Rs)", "abs error(paise)");
    for (int k = 0; k < 5; k++) {
        long n = ns[k];
        long itotal = 0; float ftotal = 0.0f;
        srand(7);
        clock_t t1 = 0, t2 = 0, s;
        long units_arr_sum = 0; (void)units_arr_sum;
        for (long i = 0; i < n; i++) {
            long u = rand() % 600;
            s = clock();
            itotal += compute_bill_paise(u);
            t1 += clock() - s;
            s = clock();
            float e = 0.0f;
            if (u > 200) e += (u - 200) * 4.50f + 100 * 2.25f;
            else if (u > 100) e += (u - 100) * 2.25f;
            ftotal += 50.0f + e;
            t2 += clock() - s;
        }
        printf("%10ld %16ld %16.2f %14.2f\n", n, itotal, ftotal, fabs(ftotal * 100.0 - itotal));
    }
    return 0;
}
