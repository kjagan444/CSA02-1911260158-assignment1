/* Task 03 - type conversion and precision */
#include <stdio.h>
#include <limits.h>

/* Rounding rule used everywhere: round HALF UP to the nearest paisa, integers only */
static long round_div(long num, long den) { return (num + den / 2) / den; }

int main(void)
{
    /* conversion point 1: integer division */
    long units = 150;
    double wrong = units / 100;          /* int/int -> 1 (fraction lost) */
    double right = units / 100.0;        /* promoted to double -> 1.5    */
    printf("1. units/100 = %.2f   (expected 1.50)   units/100.0 = %.2f\n", wrong, right);

    /* conversion point 2: float truncation of money */
    int p_wrong = (int)(19.99 * 100);                 /* 1998.99999... -> 1998 */
    long p_right = (long)(19.99 * 100 + 0.5);         /* round half up -> 1999  */
    printf("2. (int)(19.99*100) = %d   rounded = %ld   (expected 1999)\n", p_wrong, p_right);

    /* conversion point 3: long -> int cast */
    long big = 5000000000L;
    int cut = (int)big;
    printf("3. (int)5000000000L = %d   (expected 5000000000)\n", cut);

    /* conversion point 4: unsigned arithmetic on meter readings */
    unsigned prev = 65400u, curr = 100u;
    int naive = (int)(curr - prev);                   /* unsigned wrap, then int */
    printf("4. curr - prev (65400 -> 100) = %d   (rollover gives 236)\n", naive);

    /* conversion point 5: signed/unsigned comparison */
    int a = -1; unsigned b = 1u;
    printf("5. (-1 < 1u) is %d   (expected 1)\n", a < b);

    /* conversion point 6: float cannot hold large money exactly */
    float f = 16777216.0f;
    printf("6. 16777216.0f + 1 = %.1f   (float loses the +1)\n", f + 1.0f);

    /* rounding rule demo: 5%% surcharge in paise */
    long bill = 16250;
    printf("\nRounding rule demo: 5%% of %ld paise = %ld paise (round half up)\n",
           bill, round_div(bill * 5, 100));
    printf("                    5%% of 16290 paise = %ld paise (814.5 -> 815)\n",
           round_div(16290L * 5, 100));
    return 0;
}
