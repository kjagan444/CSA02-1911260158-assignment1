# CSA02-<RegisterNumber>-Assignment1 — Grama Jyothi Billing Program

- **Name:** <Your Name>
- **Register number:** <RegisterNumber>
- **Compiler:** gcc 13.3.0 (Ubuntu 24.04) — check yours with `gcc --version`
- **Scenario:** Grama Jyothi Rural Electricity Co-operative (fixed Rs 50.00 + slabs: first 100 units free, next 100 at Rs 2.25, above 200 at Rs 4.50)

## Key design decisions (apply to all tasks)
- **Money is stored as an integer number of paise** (`long`), never as float. Every bill is exact to the paisa.
- **Meter rollover** (65535 -> 0) is handled in `units_consumed()` using `METER_MODULUS = 65536`.
- **Tariff constants live only in `billing.h`**, so a tariff revision is applied everywhere or nowhere.
- Note: `long` is 64-bit on Linux/gcc. On Windows (MinGW) `long` is 32-bit — use `long long` and `%lld` there.

## Folder layout
| Folder | Contents |
|---|---|
| Task01 | `billing.h` (include guards, DEBUG macro), `billing.c`, `main.c`, `input.txt`, normal + debug outputs |
| Task02 | `main.c` (scanf validation), `specifiers.c`, `scanf_wrong.c`, `input.txt`, outputs |
| Task03 | `main.c` (conversion surprises), `bench_float.c` (error growth), outputs |
| Task04 | compile-stage outputs, error/warning demos, `split/` multi-file build with Makefile |
| ANALYSIS.md | Discussion points, Big-O analysis of the alternative concepts, Design Challenge |

## How to compile and run
### Task01
```
cd Task01
gcc -Wall -Wextra -o bill main.c billing.c
./bill < input.txt                                   # normal
gcc -Wall -Wextra -DDEBUG -o bill_debug main.c billing.c
./bill_debug < input.txt                             # debug lines on stderr
```
Result: 7 bills, e.g. house 102 (150 units) = Rs 162.50, house 103 (rollover, 236 units) = Rs 437.00, total Rs 4899.50.

### Task02
```
cd Task02
gcc -Wall -Wextra -o bill main.c billing.c && ./bill < input.txt
gcc -o specifiers specifiers.c && ./specifiers       # gcc warns on the deliberate wrong %d
gcc -w -o scanf_wrong scanf_wrong.c && ./scanf_wrong
```
Result: 3 valid bills, 3 bad lines rejected (letters, out-of-range reading, trailing garbage).

### Task03
```
cd Task03
gcc -Wall -Wextra -o conv main.c && ./conv           # warning on line 33 is the deliberate -1 < 1u demo
gcc -O0 -o bench_float bench_float.c billing.c -lm && ./bench_float
```
Result: 6 conversion surprises explained; float total is off by about Rs 10,013 at 10^5 bills, while integer paise stays exact.

### Task04
```
cd Task04
gcc -E main.c -o main.i ; gcc -S main.c -o main.s ; gcc -c main.c billing.c ; gcc main.o billing.o -o bill
gcc -c err_compile.c ; gcc err_link.c -o err_link ; gcc err_run.c -o err_run && ./err_run
gcc -Wall -Wextra -c warn_before.c ; gcc -Wall -Wextra warn_after.c -o warn_after
cd split && make && ./bill < ../input.txt
```
Saved evidence: `stages_output.txt`, `errors_output.txt`, `warnings_output.txt`, `build_times.txt`.

## Commit plan (at least one commit per task)
```
git add Task01 && git commit -m "Task01: header file, include guards, DEBUG mode"
git add Task02 && git commit -m "Task02: scanf/printf with input validation"
git add Task03 && git commit -m "Task03: type conversion and rounding analysis"
git add Task04 ANALYSIS.md README.md && git commit -m "Task04: compilation stages, errors, split build; analysis"
```
Take output screenshots of each program in your own terminal and save them in each Task folder.
