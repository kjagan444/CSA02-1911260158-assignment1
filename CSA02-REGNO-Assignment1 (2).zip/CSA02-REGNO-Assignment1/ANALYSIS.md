# Analysis — Grama Jyothi Billing (CSA02 Assignment 1)

Measurements were taken with gcc 13.3.0, x86-64 Linux. Timings vary by machine — re-run on yours and replace the numbers if you can.

## Scenario analysis
Problems in the old spreadsheet and the fix in C:
| Problem | Cause | Fix |
|---|---|---|
| Bills off by a few paise | float rounding | integer paise, no float in billing |
| Negative bill after 65535 -> 0 | `curr - prev` goes negative | `units_consumed()` adds `METER_MODULUS` when `curr < prev` |
| Tariff revision applied partly | rate typed in many places | constants only in `billing.h` |
| Growth 4,000 -> 800,000 houses | volume | stream one record at a time: O(1) memory, O(H) time; district total in `long` (80 crore Rs = 8x10^10 paise > int range) |

## Task 1 — Header file and conditional compilation
**Structure of the program:** `billing.h` (constants, prototypes, DBG macro) -> `billing.c` (function definitions) -> `main.c` (`main()` reads, calls, prints). Header holds declarations; `.c` files hold definitions.
**Include guards** (`#ifndef BILLING_H / #define / #endif`) stop the header being pasted twice into one translation unit when it is included directly and via another header, which would cause redefinition errors.
**`#ifdef DEBUG`:** `gcc -DDEBUG` turns `DBG(...)` into an `fprintf(stderr, ...)`; without it, `DBG(...)` becomes `((void)0)` and the code does not exist in the executable. Output files: `output_normal.txt`, `output_debug.txt`.
**`#include <file>` vs `"file"`:** `<>` searches the system include directories only; `""` searches the current/source directory first, then the system ones. Use `""` for our own headers.

**Alternative: run-time `if (debug) printf(...)`**
| | `#ifdef DEBUG` | run-time `if (debug)` |
|---|---|---|
| Extra time per call | none (code removed) | one compare+branch, O(1) per call -> O(n) over n calls |
| Measured, 4x10^8 calls, -O0 | 0.966 s | 0.929 s (difference is noise) |
| Measured, -O2 | 0.126 s | 0.125 s |
| Space left in executable | none | debug code + strings stay: text 1665 -> 1865 B, bss 8 -> 24 B |
| Switch debug on/off | recompile | no recompile (flag/option) |
Conclusion: the branch is well predicted so time cost is negligible here; the real difference is the space and that run-time debug code ships to users. Both are O(1) space, but `#ifdef` has zero cost.

## Task 2 — Read and print data correctly
Specifiers: `%d` int, `%u` unsigned, `%ld` long, `%lld` long long, `%f` float (printf), `%lf` double (scanf), `%c` char, `%s` string — see `output_specifiers.txt`.
**Wrong specifier test:** `printf("%d", 5000000000L)` prints `705032704` (low 32 bits); `%u` of -42 prints `4294967254`; `sscanf("4.5","%f",&double)` leaves the double wrong (`0.000000`), `%lf` gives `4.500000`. gcc warns with `-Wformat`.
**Checking `scanf`:** it returns the number of items converted (or `EOF`). In `main.c`, a return != 3 means invalid input such as letters; the rest of the bad line is discarded, otherwise the same bad characters would be re-read forever. Trailing garbage like `12x` is also caught. Output: `output.txt` (3 valid, 3 rejected).
**Rupees and paise from paise:** `printf("%ld.%02ld", p/100, p%100)` -> 16250 -> `162.50`.

**Alternative: `fgets` + `sscanf`/`strtol`**
| | `scanf` directly | `fgets` + `sscanf` |
|---|---|---|
| Time for a line of length L | O(L) | O(L) read + O(L) parse (two passes) |
| Space | O(1) (just the variables) | O(B) buffer (256 B here); O(L) to hold a full line |
| Recovery from bad input | manual: must consume the leftover characters | automatic: whole line already consumed, just skip it |
| Measured, 1M lines | 0.155 s | 0.181 s |
| Measured, 5M lines | 0.848 s | 0.939 s |
`fgets` is ~10-17% slower but safer; `strtol` additionally gives an end pointer and `errno` to detect range errors and junk. For a billing system correctness beats that small cost.

## Task 3 — Type conversion and precision
Conversion points and the three-plus surprises (`Task03/output.txt`):
1. `units / 100` with `long` operands is integer division -> `1.00`, not `1.50`. Use `100.0`.
2. `(int)(19.99 * 100)` = `1998`: 19.99 is stored as 19.989999..., and casting truncates. Rounded `(long)(x*100 + 0.5)` = `1999`.
3. `(int)5000000000L` = `705032704`: casting a large `long` to `int` keeps only the low 32 bits.
4. `curr - prev` with unsigned wraps: 65400 -> 100 gives `-65300` after `(int)`, not 236.
5. `-1 < 1u` is `0`: the `int` is converted to `unsigned` (usual arithmetic conversions) so -1 becomes 4294967295.
6. `16777216.0f + 1` stays `16777216.0`: a float has only 24 bits of mantissa.
**Rounding rule (used everywhere):** keep all amounts in integer paise; when a fraction appears (e.g. a 5% surcharge), round **half up** with `(num + den/2) / den`. Rounded once, at the end of a calculation.

**Alternative: float arithmetic, round once at the end** (`bench_float.c`, random units 0-599 per bill):
| n bills | integer total (exact) | float total error |
|---|---|---|
| 1,000 | 0 | 0 paise |
| 10,000 | 0 | 550 paise (Rs 5.50) |
| 100,000 | 0 | 1,001,325 paise (Rs 10,013) |
| 1,000,000 | 0 | 147,233,550 paise (Rs 14.7 lakh) |
| 10,000,000 | 0 | 11,462,146,100 paise (Rs 11.5 crore) |
Error does not just grow with n — it grows faster than linearly: each addition loses up to half an ulp of the running total, and the ulp grows as the total grows, so total error is roughly O(n^2 x epsilon) for a total proportional to n. Integer paise stay exact until overflow of `long`.
Time per value: both O(1). Space per value: float 4 B vs `long` 8 B. Float is smaller, but not usable for money.

## Task 4 — Compilation process
Evidence in `stages_output.txt` for `main.c`:
- `gcc -E`: 25 lines -> 847 lines. Headers pasted in, comments removed, `DBG(...)` macro expanded to nothing (DEBUG undefined).
- `gcc -S`: 115 lines of x86-64 assembly, format strings in `.rodata`.
- `gcc -c`: `main.o` (2400 B) — machine code with **undefined symbols** (`U units_consumed`, `U printf`, ...) listed by `nm`.
- Link: `main.o + billing.o + libc` -> `bill` (16,296 B); every `U` symbol is resolved.
**What the preprocessor removed/replaced:** `#include` lines (replaced by file text), `#define` constants (replaced by values), `DBG` macro, comments, include-guard/`#ifdef` blocks.
**Three kinds of error** (`errors_output.txt`):
- Compile-time: `err_compile.c` — missing `;` -> `error: expected ',' or ';' before 'printf'`. No object file produced.
- Link-time: `err_link.c` — `compute_tax` declared but not defined -> `undefined reference to 'compute_tax'`, `ld returned 1 exit status`.
- Run-time: `err_run.c` — compiles and links, then dies with `Floating point exception` (exit 136), integer division by zero.
**Warnings with `-Wall -Wextra`** (`warnings_output.txt`): (1) `%d` used with `long` -> changed to `%ld`; (2) signed/unsigned comparison `int < unsigned` -> both `unsigned`; (3) unused variable -> removed. After fixes: no warnings.

**Alternative: several `.c` files with a shared header** (`Task04/split`, `Makefile`; `build_times.txt`)
| | Single file (`main.c billing.c` in one gcc call) | Split (`input.c tariff.c report.c` + Makefile) |
|---|---|---|
| Change one `.c` file | recompile everything: 1.198 s / 20 = 60 ms | only that file + link: 0.884 s / 20 = 44 ms (~26% faster) |
| Change `billing.h` | recompile everything: 60 ms | all 3 files depend on it: 92 ms (slower — 3 gcc runs + link) |
| Object file space | `main.o` 2400 B + `billing.o` 1984 B = 4384 B | 2248 + 1560 + 1416 = 5224 B (each `.o` has its own headers/symbol tables) |
Split builds win when a change touches one source file; they cost a bit more space and lose when the shared header changes. With n files and one changed, recompile time is O(size of that file) + link, versus O(total size) for a single file — a real saving at the 60,000-house scale of a real codebase, negligible for this toy.

## Design Challenge — smart meters every 15 minutes and time-of-day tariff
Volume: 96 readings per house per day -> about 11.5 million readings/month for a village (4,000 houses), 173 million for a taluk, 2.3 billion for a district.
| Decision | Verdict |
|---|---|
| Integer paise, header with constants, `units_consumed()` with modulus | **Retain** — correct and still needed (smart meters wrap too; use a 32-bit modulus) |
| Tariff as `#define` constants | **Modify** — time-of-day needs a table (`struct {start_hour, end_hour, rate_paise}`), so a revision is one data change |
| Per-house monthly record read with `scanf` | **Redesign** — 2 billion text lines is too slow; read a binary or CSV file using a buffered `fgets`/`fread`, one record at a time |
| One `main.c` | **Redesign** — split into `input.c`, `tariff.c`, `report.c` + Makefile (Task 4) |
| Rounding | **Modify** — compute `units x rate` per interval exactly in integers and round **once per bill**, never per interval, or paise errors add up (Task 3) |
| Totals | `long long` (district total ~8x10^10 paise overflows 32-bit int) |
Time complexity: O(R) for R readings (each read once). Space: O(1) if readings arrive sorted by house, O(H) for H per-house accumulators otherwise. Slab pricing applies to monthly total units, so keep per-house running totals (units per time-slot) and price them at month end. Houses are independent, so the work can also be parallelised per house or per file.
