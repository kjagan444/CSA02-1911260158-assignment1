/* Alternative concept: slab arrays + loop vs fixed if-statements.  Time per bill vs s */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include "billing.h"

static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec*1e-9; }

static long bill_generic(const long *lim, const long *rate, int s, long units)
{
    long energy = 0, lower = 0;
    for (int i = 0; i < s && units > lower; i++) {
        long upper = lim[i];
        energy += ((units < upper ? units : upper) - lower) * rate[i];
        lower = upper;
    }
    return 5000 + energy;
}

int main(void)
{
    enum { M = 1000000, REP = 100 };
    static long units[M]; volatile long sink = 0;
    srand(3);
    for (int i = 0; i < M; i++) units[i] = rand() % 600;
    double t0 = now(); long s = 0;
    for (int r = 0; r < REP; r++) for (int i = 0; i < M; i++) s += bill_if(units[i]);
    double t1 = now(); sink = s;
    printf("fixed ifs (3 slabs) : %.2f ns/bill\n", (t1-t0)/((double)M*REP)*1e9);
    t0 = now(); s = 0;
    for (int r = 0; r < REP; r++) for (int i = 0; i < M; i++) s += bill_loop(units[i]);
    t1 = now(); sink = s;
    printf("loop, 3 slabs       : %.2f ns/bill\n", (t1-t0)/((double)M*REP)*1e9);

    int sizes[] = {3, 10, 50, 200};
    for (int k = 0; k < 4; k++) {
        int n = sizes[k];
        long *lim = malloc(n*sizeof(long)), *rate = malloc(n*sizeof(long));
        for (int i = 0; i < n-1; i++) { lim[i] = 10L*(i+1); rate[i] = 10L*i; }
        lim[n-1] = LONG_MAX; rate[n-1] = 10L*n;
        srand(5);
        for (int i = 0; i < M; i++) units[i] = rand() % (10*n + 10);   /* spread across all slabs */
        int rep = REP * 3 / n + 1;
        t0 = now(); s = 0;
        for (int r = 0; r < rep; r++) for (int i = 0; i < M; i++) s += bill_generic(lim, rate, n, units[i]);
        t1 = now(); sink = s;
        printf("loop, s=%3d slabs   : %.2f ns/bill   (extra space: %zu bytes for the 2 arrays)\n",
               n, (t1-t0)/((double)M*rep)*1e9, 2*n*sizeof(long));
        free(lim); free(rate);
    }
    (void)sink;
    return 0;
}
