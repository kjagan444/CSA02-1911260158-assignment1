/* Task 01 - test table: expected vs actual for every case */
#include <stdio.h>
#include <string.h>
#include "billing.h"

struct test { const char *name; const char *line; int exp_status; long exp_paise; };

static const struct test T[] = {
 /* normal bills, one per slab */
 {"normal, slab 1 (free)",       "100 150",    BILL_OK,   5000},   /* 50 units  */
 {"normal, slab 2",              "1000 1150",  BILL_OK,  16250},   /* 150 units */
 {"normal, slab 3",              "2000 2300",  BILL_OK,  72500},   /* 300 units */
 /* boundaries */
 {"boundary: 0 units",           "500 500",    BILL_OK,   5000},
 {"boundary: exactly 100 units", "0 100",      BILL_OK,   5000},
 {"boundary: 101 units",         "0 101",      BILL_OK,   5225},
 {"boundary: exactly 200 units", "0 200",      BILL_OK,  27500},
 {"boundary: 201 units",         "0 201",      BILL_OK,  27950},
 /* rollover */
 {"rollover 65535 -> 0",         "65535 0",    BILL_OK,   5000},   /* 1 unit    */
 {"rollover 65400 -> 100",       "65400 100",  BILL_OK,  43700},   /* 236 units */
 {"rollover 65436 -> 0 (100)",   "65436 0",    BILL_OK,   5000},
 /* invalid input */
 {"invalid: letters",            "abc 100",    ERR_FORMAT,  0},
 {"invalid: letters in current", "100 12x",    ERR_FORMAT,  0},
 {"invalid: one number only",    "100",        ERR_FORMAT,  0},
 {"invalid: negative reading",   "-5 100",     ERR_RANGE,   0},
 {"invalid: negative current",   "100 -1",     ERR_RANGE,   0},
 {"invalid: above 65535",        "70000 10",   ERR_RANGE,   0},
 {"invalid: decrease, no rollover","500 300",  ERR_DECREASE,0},
};
#define NT (int)(sizeof T / sizeof T[0])

static const char *status_name(int s)
{ return s==BILL_OK?"OK":s==ERR_FORMAT?"ERR_FORMAT":s==ERR_RANGE?"ERR_RANGE":"ERR_DECREASE"; }

int main(void)
{
    int pass = 0;
    printf("%-32s %-12s %-13s %-13s %-9s %-9s %s\n",
           "case","input","exp status","act status","exp Rs","act Rs","result");
    for (int i = 0; i < NT; i++) {
        long prev = 0, curr = 0, units = 0, paise = 0;
        int st = parse_readings(T[i].line, &prev, &curr);
        if (st == BILL_OK) st = units_between(prev, curr, &units);
        if (st == BILL_OK) {
            paise = bill_if(units);
            if (paise != bill_loop(units)) st = 99;      /* the two designs must agree */
        }
        int ok = (st == T[i].exp_status) && (st != BILL_OK || paise == T[i].exp_paise);
        printf("%-32s %-12s %-13s %-13s %6ld.%02ld %6ld.%02ld %s\n",
               T[i].name, T[i].line, status_name(T[i].exp_status), status_name(st),
               T[i].exp_paise/100, T[i].exp_paise%100, paise/100, paise%100, ok?"PASS":"FAIL");
        pass += ok;
    }
    printf("\n%d / %d cases passed\n", pass, NT);

    /* five bills calculated by hand: 80,120,200,250,0 units */
    long u5[5] = {80,120,200,250,0};
    long hand[5] = {5000, 9500, 27500, 50000, 5000};   /* hand total = 97000 = Rs 970.00 */
    long total = 0; int ok5 = 1;
    printf("\nHand-calculated set of 5 bills:\nunits  hand(paise)  program(paise)\n");
    for (int i = 0; i < 5; i++) {
        long b = bill_if(u5[i]); total += b; ok5 &= (b == hand[i]);
        printf("%5ld  %11ld  %14ld\n", u5[i], hand[i], b);
    }
    printf("total: hand = 97000 paise (Rs 970.00), program = %ld paise  -> %s\n",
           total, (ok5 && total == 97000) ? "PASS" : "FAIL");

    /* both designs must agree for every possible consumption up to 5000 units */
    int agree = 1;
    for (long u = 0; u <= MAX_PLAUSIBLE_UNITS; u++) if (bill_if(u) != bill_loop(u)) agree = 0;
    printf("if-version vs loop-version for 0..%ld units: %s\n", MAX_PLAUSIBLE_UNITS, agree?"identical":"DIFFERENT");
    return (pass == NT && ok5 && agree) ? 0 : 1;
}
