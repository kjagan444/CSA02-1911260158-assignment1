#ifndef BILLING_H
#define BILLING_H

/* ---- Tariff and meter constants: the ONLY place they are written ---- */
#define METER_MODULUS        65536L   /* 16-bit meter: 0..65535, then 0      */
#define METER_MAX            65535L
#define MAX_PLAUSIBLE_UNITS  5000L    /* a "decrease" is a rollover only if the
                                         implied consumption is <= this      */
#define FIXED_CHARGE_PAISE   5000L    /* Rs 50.00                            */
#define NSLABS               3
#define SLAB1_LIMIT          100L     /* first 100 units free                */
#define SLAB2_LIMIT          200L     /* next 100 units at Rs 2.25           */
#define RATE1_PAISE          0L
#define RATE2_PAISE          225L
#define RATE3_PAISE          450L     /* above 200 units at Rs 4.50          */

/* status codes */
#define BILL_OK        0
#define ERR_FORMAT     1   /* not two integers (letters etc.)                */
#define ERR_RANGE      2   /* negative or above 65535                        */
#define ERR_DECREASE   3   /* current < previous and not a plausible rollover*/

int  parse_readings(const char *line, long *prev, long *curr);
int  units_between(long prev, long curr, long *units);
long bill_if(long units);     /* version A: fixed if-statements              */
long bill_loop(long units);   /* version B: slab arrays + loop               */

#endif /* BILLING_H */
