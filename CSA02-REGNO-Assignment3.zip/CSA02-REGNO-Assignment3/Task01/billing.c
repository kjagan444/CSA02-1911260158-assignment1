#include <stdlib.h>
#include <limits.h>
#include <ctype.h>
#include "billing.h"

/* Reads exactly two integers; anything else (letters, extra text) is ERR_FORMAT */
int parse_readings(const char *line, long *prev, long *curr)
{
    char *end;
    *prev = strtol(line, &end, 10);
    if (end == line) return ERR_FORMAT;
    const char *p = end;
    *curr = strtol(p, &end, 10);
    if (end == p) return ERR_FORMAT;
    while (*end) { if (!isspace((unsigned char)*end)) return ERR_FORMAT; end++; }
    return BILL_OK;
}

int units_between(long prev, long curr, long *units)
{
    if (prev < 0 || curr < 0 || prev > METER_MAX || curr > METER_MAX)
        return ERR_RANGE;
    if (curr >= prev) { *units = curr - prev; return BILL_OK; }
    long u = METER_MODULUS - prev + curr;           /* meter rolled over */
    if (u > MAX_PLAUSIBLE_UNITS) return ERR_DECREASE; /* really a bad reading */
    *units = u;
    return BILL_OK;
}

long bill_if(long units)
{
    long energy = 0;
    if (units > SLAB2_LIMIT) {
        energy += (units - SLAB2_LIMIT) * RATE3_PAISE;
        energy += (SLAB2_LIMIT - SLAB1_LIMIT) * RATE2_PAISE;
    } else if (units > SLAB1_LIMIT) {
        energy += (units - SLAB1_LIMIT) * RATE2_PAISE;
    }
    return FIXED_CHARGE_PAISE + energy;
}

static const long LIMIT[NSLABS] = { SLAB1_LIMIT, SLAB2_LIMIT, LONG_MAX };
static const long RATE [NSLABS] = { RATE1_PAISE, RATE2_PAISE, RATE3_PAISE };

long bill_loop(long units)
{
    long energy = 0, lower = 0;
    for (int i = 0; i < NSLABS && units > lower; i++) {
        long upper = LIMIT[i];
        long in_slab = (units < upper ? units : upper) - lower;
        energy += in_slab * RATE[i];
        lower = upper;
    }
    return FIXED_CHARGE_PAISE + energy;
}
