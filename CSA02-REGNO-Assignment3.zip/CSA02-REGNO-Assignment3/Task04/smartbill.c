/* Task 04 - smart-meter billing: 15-minute readings in Wh, time-of-day tariff, tariff in a config file.
   usage: smartbill tariff.cfg readings.txt [-q]
   readings.txt lines:  house_id  day  slot  wh      (slot 0..95; slot*15 min from midnight)
   Readings of one house must be together and in time order (streamed, nothing stored). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef long long i64;
#define MAX_SLABS 16
#define SCALE 100000LL    /* Wh x (paise per kWh) x percent  =  paise x 1000 x 100 */

typedef struct {
    i64 limit_wh[MAX_SLABS];   /* cumulative upper limit of slab in Wh (LLONG_MAX = no limit) */
    i64 rate[MAX_SLABS];       /* paise per kWh */
    int n;
    i64 fixed_paise;
    int peak_start, peak_end, peak_pct;   /* peak when peak_start <= hour < peak_end */
} Tariff;

static int load_tariff(const char *path, Tariff *t)
{
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); return 1; }
    char line[128], lim[32]; long a, b; t->n = 0; t->fixed_paise = -1;
    t->peak_start = 18; t->peak_end = 22; t->peak_pct = 0;
    while (fgets(line, sizeof line, f)) {
        if (line[0] == '#') continue;
        if (sscanf(line, "fixed_charge_paise %ld", &a) == 1) t->fixed_paise = a;
        else if (sscanf(line, "peak_hours %ld %ld", &a, &b) == 2) { t->peak_start = (int)a; t->peak_end = (int)b; }
        else if (sscanf(line, "peak_percent %ld", &a) == 1) t->peak_pct = (int)a;
        else if (sscanf(line, "slab %31s %ld", lim, &a) == 2) {
            if (t->n >= MAX_SLABS) { fclose(f); return 2; }
            t->limit_wh[t->n] = strcmp(lim, "inf") == 0 ? LLONG_MAX : (i64)atol(lim) * 1000;
            t->rate[t->n] = a; t->n++;
        }
    }
    fclose(f);
    if (t->fixed_paise < 0 || t->n < 1 || t->limit_wh[t->n-1] != LLONG_MAX) return 3;
    for (int i = 0; i < t->n; i++) {
        if (t->rate[i] < 0) return 4;
        if (i && t->limit_wh[i] <= t->limit_wh[i-1]) return 5;
    }
    if (t->peak_start < 0 || t->peak_end > 24 || t->peak_start >= t->peak_end) return 6;
    if (t->peak_pct < 0 || t->peak_pct > 1000) return 7;
    return 0;
}

/* Add one reading. Slab is decided by cumulative monthly Wh, so a reading can straddle slabs.
   Cost is kept in exact integers (scaled); rounding happens ONCE, in house_paise(). */
static void add_reading(const Tariff *t, i64 *cum_wh, i64 *cost, i64 wh, int slot)
{
    int hour = slot / 4;
    i64 mult = 100 + ((hour >= t->peak_start && hour < t->peak_end) ? t->peak_pct : 0);
    i64 remain = wh;
    for (int i = 0; i < t->n && remain > 0; i++) {
        if (*cum_wh >= t->limit_wh[i]) continue;
        i64 room = t->limit_wh[i] - *cum_wh;
        i64 take = remain < room ? remain : room;
        *cost += take * t->rate[i] * mult;
        *cum_wh += take; remain -= take;
    }
}

static i64 house_paise(const Tariff *t, i64 cost)
{
    return t->fixed_paise + (cost + SCALE / 2) / SCALE;      /* round half up, once */
}

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s tariff.cfg readings.txt [-q]\n", argv[0]); return 1; }
    int quiet = argc > 3 && strcmp(argv[3], "-q") == 0;
    Tariff t; int rc = load_tariff(argv[1], &t);
    if (rc) { fprintf(stderr, "bad tariff file (code %d) - refusing to bill\n", rc); return rc; }
    FILE *f = fopen(argv[2], "r"); if (!f) { fprintf(stderr, "cannot open %s\n", argv[2]); return 1; }

    char line[128]; long houses = 0, readings = 0, bad = 0, lineno = 0;
    i64 total = 0, cum = 0, cost = 0, cur = -1;
    while (fgets(line, sizeof line, f)) {
        lineno++;
        char *p = line, *e; long v[4]; int k;
        for (k = 0; k < 4; k++) { v[k] = strtol(p, &e, 10); if (e == p) break; p = e; }
        while (k == 4 && (*p == ' ' || *p == '\t' || *p == '\r')) p++;
        if (k != 4 || (*p != '\n' && *p != '\0') || v[2] < 0 || v[2] > 95 || v[3] < 0) {
            bad++; if (!quiet) printf("line %ld: invalid reading skipped\n", lineno); continue;
        }
        if (v[0] != cur) {                                   /* new house: close the previous one */
            if (cur >= 0) { i64 b = house_paise(&t, cost); total += b; houses++;
                if (!quiet) printf("house %-6lld %8lld Wh  Rs %lld.%02lld\n", cur, cum, b/100, b%100); }
            cur = v[0]; cum = 0; cost = 0;
        }
        add_reading(&t, &cum, &cost, v[3], (int)v[2]); readings++;
    }
    if (cur >= 0) { i64 b = house_paise(&t, cost); total += b; houses++;
        if (!quiet) printf("house %-6lld %8lld Wh  Rs %lld.%02lld\n", cur, cum, b/100, b%100); }
    fclose(f);
    printf("houses=%ld readings=%ld invalid=%ld  TOTAL Rs %lld.%02lld\n", houses, readings, bad, total/100, total%100);
    return 0;
}
