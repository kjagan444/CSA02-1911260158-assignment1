# Independent check: recompute every bill with exact fractions and compare with the C program.
import sys, subprocess
from fractions import Fraction
from math import floor
def load(path):
    t = {'slabs': [], 'ps': 18, 'pe': 22, 'pp': 0}
    for l in open(path):
        w = l.split()
        if not w or w[0].startswith('#'): continue
        if w[0] == 'fixed_charge_paise': t['fixed'] = int(w[1])
        elif w[0] == 'slab': t['slabs'].append((None if w[1] == 'inf' else int(w[1]) * 1000, int(w[2])))
        elif w[0] == 'peak_hours': t['ps'], t['pe'] = int(w[1]), int(w[2])
        elif w[0] == 'peak_percent': t['pp'] = int(w[1])
    return t
def bills(t, path):
    out, cur, cum, cost = {}, None, 0, Fraction(0)
    for l in open(path):
        w = l.split()
        try:
            if len(w) != 4: raise ValueError
            h, d, s, wh = map(int, w)
            if not (0 <= s <= 95 and wh >= 0): raise ValueError
        except ValueError: continue
        if h != cur:
            if cur is not None: out[cur] = t['fixed'] + floor(cost + Fraction(1, 2))
            cur, cum, cost = h, 0, Fraction(0)
        mult = Fraction(100 + (t['pp'] if t['ps'] <= s // 4 < t['pe'] else 0), 100)
        remain = wh
        for lim, rate in t['slabs']:
            if remain == 0: break
            if lim is not None and cum >= lim: continue
            take = remain if lim is None else min(remain, lim - cum)
            cost += Fraction(take * rate, 1000) * mult
            cum += take; remain -= take
    if cur is not None: out[cur] = t['fixed'] + floor(cost + Fraction(1, 2))
    return out
cfg, data = sys.argv[1], sys.argv[2]
exp = bills(load(cfg), data)
res = subprocess.run(['./smartbill', cfg, data], capture_output=True, text=True).stdout
got = {int(l.split()[1]): round(float(l.split()[-1]) * 100) for l in res.splitlines() if l.startswith('house ')}
ok = exp == got
print(cfg, data, '->', 'ALL', len(exp), 'BILLS MATCH' if ok else 'MISMATCH')
for h in sorted(exp): print('  house', h, 'oracle', exp[h], 'paise   C program', got.get(h), 'paise')
sys.exit(0 if ok else 1)
