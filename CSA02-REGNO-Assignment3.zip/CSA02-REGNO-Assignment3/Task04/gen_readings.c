/* synthetic month of readings: gen_readings houses days > file */
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv)
{
    long H = atol(argv[1]), D = atol(argv[2]);
    unsigned long long s = 99;
    for (long h = 1; h <= H; h++)
        for (long d = 0; d < D; d++)
            for (int slot = 0; slot < 96; slot++) {
                s = s * 6364136223846793005ULL + 1442695040888963407ULL;
                int hour = slot / 4;
                long wh = 40 + (long)((s >> 40) % 180) + ((hour >= 18 && hour < 22) ? 150 : 0);
                printf("%ld %ld %d %ld\n", h, d, slot, wh);
            }
    return 0;
}
