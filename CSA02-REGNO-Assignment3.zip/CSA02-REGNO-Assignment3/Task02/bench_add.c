/* time per addition and space per variable: long long vs double vs float */
#include <stdio.h>
#include <time.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec*1e-9; }
int main(void)
{
    enum { N = 400000000 };
    static long long xi[1024]; static double xd[1024]; static float xf[1024];
    for (int i = 0; i < 1024; i++) { xi[i] = i % 600; xd[i] = i % 600; xf[i] = (float)(i % 600); }
    volatile long long si = 0; volatile double sd = 0; volatile float sf = 0;
    long long a = 0; double b = 0; float c = 0;
    double t0 = now(); for (long i = 0; i < N; i++) a += xi[i & 1023]; double t1 = now(); si = a;
    printf("long long: %.3f ns/add, %zu bytes per variable\n", (t1-t0)/N*1e9, sizeof(long long));
    t0 = now(); for (long i = 0; i < N; i++) b += xd[i & 1023]; t1 = now(); sd = b;
    printf("double   : %.3f ns/add, %zu bytes per variable\n", (t1-t0)/N*1e9, sizeof(double));
    t0 = now(); for (long i = 0; i < N; i++) c += xf[i & 1023]; t1 = now(); sf = c;
    printf("float    : %.3f ns/add, %zu bytes per variable\n", (t1-t0)/N*1e9, sizeof(float));
    return 0;
}
