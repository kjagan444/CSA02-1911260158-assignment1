/* Task 02 - float vs paise totals, and int / long / long long overflow, at 4,000 / 60,000 / 800,000 bills */
#include <stdio.h>
#include <limits.h>
#include "billing.h"

int main(void)
{
    long counts[3] = {4000, 60000, 800000};
    printf("%9s | %16s | %18s %14s | %14s %12s | %s\n",
           "bills", "exact (paise)", "float total (Rs)", "float err(p)",
           "double Rs", "dbl err(p)", "int total / overflow?");
    for (int k = 0; k < 3; k++) {
        long n = counts[k];
        long long exact = 0;          /* long long paise      */
        long      lsum  = 0;          /* long paise           */
        int       isum  = 0; int ovf = 0;   /* int paise, overflow detected */
        float     ftot  = 0.0f;       /* float rupees         */
        double    dtot  = 0.0;        /* double rupees        */
        double    dpaise= 0.0;        /* double accumulating whole paise */
        unsigned long long seed = 12345;
        for (long i = 0; i < n; i++) {
            seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
            long units = (long)((seed >> 33) % 600);          /* 0..599 units */
            long p = bill_if(units);                          /* exact paise  */
            exact += p; lsum += p;
            if (__builtin_add_overflow(isum, (int)p, &isum)) ovf = 1;
            float fe = 50.0f;
            if (units > 200)      fe += (units - 200) * 4.50f + 100 * 2.25f;
            else if (units > 100) fe += (units - 100) * 2.25f;
            ftot += fe;
            double de = 50.0;
            if (units > 200)      de += (units - 200) * 4.50 + 100 * 2.25;
            else if (units > 100) de += (units - 100) * 2.25;
            dtot += de;
            dpaise += (double)p;
        }
        double ferr = (double)ftot * 100.0 - (double)exact;
        double derr = dtot * 100.0 - (double)exact;
        printf("%9ld | %16lld | %18.2f %14.0f | %14.2f %12.4f | %d%s\n",
               n, exact, (double)ftot, ferr, dtot, derr, isum, ovf ? "  OVERFLOW" : "  ok");
        printf("%9s | long=%ld %s | long long=%lld ok | double-of-paise=%.0f %s\n", "",
               lsum, (long long)lsum == exact ? "(= exact)" : "(WRONG)", exact,
               dpaise, dpaise == (double)exact ? "(= exact)" : "(differs)");
    }
    return 0;
}
