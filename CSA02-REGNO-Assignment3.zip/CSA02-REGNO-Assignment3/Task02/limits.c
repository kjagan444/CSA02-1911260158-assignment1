/* sizeof and ranges on THIS system vs the minimum sizes the C standard guarantees */
#include <stdio.h>
#include <limits.h>
#include <float.h>
int main(void)
{
    printf("%-12s %-7s %-24s | %-22s %s\n", "type", "sizeof", "max on this system", "standard minimum max", "max Rupees at minimum");
    printf("%-12s %-7zu %-24d | %-22s Rs %.2f\n", "int",       sizeof(int),       INT_MAX,  "32767 (16 bit)",        32767/100.0);
    printf("%-12s %-7zu %-24ld | %-22s Rs %.2f\n", "long",      sizeof(long),      LONG_MAX, "2147483647 (32 bit)",   2147483647/100.0);
    printf("%-12s %-7zu %-24lld | %-22s Rs %.2e\n","long long", sizeof(long long),LLONG_MAX,"9.22e18 (64 bit)",     9223372036854775807.0/100.0);
    printf("\n%-8s %-7s %-16s %-14s %s\n", "type", "sizeof", "mantissa bits", "digits (DIG)", "standard minimum DIG");
    printf("%-8s %-7zu %-16d %-14d %s\n", "float",  sizeof(float),  FLT_MANT_DIG, FLT_DIG, "6");
    printf("%-8s %-7zu %-16d %-14d %s\n", "double", sizeof(double), DBL_MANT_DIG, DBL_DIG, "10");
    printf("\nDistrict (800,000 bills x ~Rs 825) needs about 6.6e10 paise.\n");
    printf("32-bit signed max is 2.1e9 paise, so a 32-bit total overflows; long is only safe where it is 64-bit.\n");
    return 0;
}
