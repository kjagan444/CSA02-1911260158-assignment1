/* Where each type stops being accurate: overflow (integer) vs precision loss (float/double) */
#include <stdio.h>
#include <limits.h>
int main(void)
{
    long long ll = LLONG_MAX; long long res;
    int ov = __builtin_add_overflow(ll, 1LL, &res);
    printf("long long: LLONG_MAX + 1 -> overflow flag %d, wrapped value %lld  (SUDDEN, WRONG SIGN)\n", ov, res);

    double d = 9007199254740992.0;                 /* 2^53 */
    printf("double:    2^53 + 1 = %.0f   (2^53 = %.0f): the +1 is silently lost  (GRADUAL, SMALL ERROR)\n", d + 1.0, d);
    printf("           2^53 paise = Rs %.2e, far above a district total (6.6e10 paise)\n", d / 100.0);

    float f = 16777216.0f;                         /* 2^24 */
    printf("float:     2^24 + 1 = %.0f   (2^24 = %.0f), 2^24 paise is only Rs %.2f\n", f + 1.0f, f, f / 100.0f);

    double sum = 0.0;                              /* add Rs 0.01, ten million times */
    for (int i = 0; i < 10000000; i++) sum += 0.01;
    printf("double:    ten million additions of Rs 0.01 = %.10f   (exact answer 100000)  error %.3e\n", sum, sum - 100000.0);
    long long s2 = 0;
    for (int i = 0; i < 10000000; i++) s2 += 1;
    printf("long long: ten million additions of 1 paisa = %lld paise = Rs %lld.%02lld   (exact)\n", s2, s2/100, s2%100);
    return 0;
}
