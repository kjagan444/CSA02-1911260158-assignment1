# CSA02-<RegisterNumber>-Assignment — Grama Jyothi Billing (Tasks 1-4, incl. Day-4 Design Challenge)

- **Name:** <Your Name>   **Register number:** <RegisterNumber>
- **Compiler:** gcc 13.3.0 (Ubuntu 24.04) — check yours with `gcc --version`
- **Tariff:** fixed Rs 50.00; first 100 units free; next 100 at Rs 2.25; above 200 at Rs 4.50.
- **Core rule:** money is an integer number of paise in a 64-bit type; floats are never used for billing.
- `long` is 64-bit on Linux. On Windows (MinGW) it is 32-bit: change `long` to `long long` and `%ld` to `%lld`.

| Folder | What it holds |
|---|---|
| Task01 | `billing.h/.c` (if-version and slab-array version), `test_billing.c` (18-case test table + hand-checked 5 bills), `bench_slabs.c`, outputs |
| Task02 | `compare.c` (float vs paise at 4,000 / 60,000 / 800,000 bills), `limits.c`, `precision.c`, `bench_add.c`, outputs |
| Task03 | `cfg_bill.c` (tariff read from a config file), `tariff_v1/v2/bad.cfg`, start-up and recompile timings, outputs |
| Task04 | `smartbill.c` (15-minute Wh readings, evening peak, config tariff), `gen_readings.c`, `oracle.py`, tests, scale results |
| ANALYSIS.md | All discussion points, Big-O analysis, recommendation, Day-4 re-evaluation |

## How to compile and run
### Task01
```
cd Task01
gcc -Wall -Wextra -o test_billing test_billing.c billing.c && ./test_billing
gcc -O1 -o bench_slabs bench_slabs.c billing.c && ./bench_slabs
```
Result: 18/18 test cases pass (normal, boundary, rollover, invalid); hand total of 5 bills = Rs 970.00 matches.
### Task02
```
cd Task02
gcc -o compare compare.c billing.c && ./compare
gcc -o limits limits.c && ./limits
gcc -o precision precision.c && ./precision
gcc -O1 -o bench_add bench_add.c && ./bench_add
```
Result: a 32-bit int total overflows at 60,000 bills; float total is wrong by Rs 1.6 thousand at 60,000 and Rs 10 lakh at 800,000; long long is exact.
### Task03
```
cd Task03
gcc -Wall -Wextra -O2 -o cfg_bill cfg_bill.c
./cfg_bill tariff_v1.cfg units.txt ; ./cfg_bill tariff_v2.cfg units.txt ; ./cfg_bill tariff_bad.cfg units.txt
./cfg_bill tariff_v1.cfg --bench 2000
```
(Copy `../Task01/billing.[ch]` here only if you rebuild the recompile-time test.) Result: tariff revision with no recompile; a bad file is rejected.
### Task04
```
cd Task04
gcc -Wall -Wextra -O2 -o smartbill smartbill.c && gcc -O2 -o gen_readings gen_readings.c
./smartbill tariff_v1.cfg test_readings.txt ; ./smartbill tariff_v2.cfg test_readings.txt
python3 oracle.py tariff_v1.cfg test_readings.txt          # independent exact check
./gen_readings 2000 30 > month.txt && time ./smartbill tariff_v1.cfg month.txt -q
```
Result: all hand-checked bills match (house 1 = Rs 230.00, house 4 = Rs 59.90); oracle matches on 25 houses x 30 days too.

## Commit plan (at least one commit per task)
```
git add Task01 && git commit -m "Task01: billing program, test table, slab-array alternative"
git add Task02 && git commit -m "Task02: float vs paise, integer ranges, precision"
git add Task03 && git commit -m "Task03: final design, config-file tariff"
git add Task04 README.md ANALYSIS.md && git commit -m "Task04: smart-meter redesign"
```
Take output screenshots in your own terminal and save them in each Task folder.
