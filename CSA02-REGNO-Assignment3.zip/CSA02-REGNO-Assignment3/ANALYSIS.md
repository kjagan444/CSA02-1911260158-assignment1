# Analysis — Grama Jyothi Billing (Tasks 1-4)
Timings: gcc 13.3.0, x86-64 Linux, one core. They vary by machine; re-run on yours and replace numbers if different.

## Task 1 — Implement and test (4 marks)
**Design:** all tariff/meter constants are `#define`d once in `billing.h`. `parse_readings()` accepts exactly two integers (letters, missing or extra text give `ERR_FORMAT`); `units_between()` rejects negatives and values above 65535 (`ERR_RANGE`) and handles rollover with `METER_MODULUS`. A decrease is a **rollover only if the implied consumption is at most 5000 units**; so 65400 -> 100 = 236 units is accepted, but 500 -> 300 (which would mean 65,336 units) is `ERR_DECREASE`. Bills are integer paise.

**Test table** (`Task01/output_tests.txt`, 18/18 PASS):
| Group | Cases (input -> expected) |
|---|---|
| Normal | 50 units -> Rs 50.00; 150 -> Rs 162.50; 300 -> Rs 725.00 |
| Boundary | 0 -> 50.00; 100 -> 50.00; 101 -> 52.25; 200 -> 275.00; 201 -> 279.50 |
| Rollover | 65535 -> 0 = 1 unit, Rs 50.00; 65400 -> 100 = 236 units, Rs 437.00 |
| Invalid | `abc 100`, `100 12x`, `100` (format); `-5 100`, `100 -1`, `70000 10` (range); `500 300` (decrease) |
**Hand-calculated 5 bills** (80, 120, 200, 250, 0 units): 50.00 + 95.00 + 275.00 + 500.00 + 50.00 = **Rs 970.00**; program total 97000 paise — PASS. Both bill functions agree for every consumption 0..5000.

**Alternative: slab arrays + loop** (`bench_slabs.c`, measured):
| Design | Time per bill | Extra space |
|---|---|---|
| fixed `if` statements (3 slabs) | 5.30 ns | none |
| loop over arrays, s = 3 | 7.39 ns | 48 B (2 arrays of 3 `long`) |
| loop, s = 10 | 13.6 ns | 160 B |
| loop, s = 50 | 31.6 ns | 800 B |
| loop, s = 200 | 91.7 ns | 3,200 B |
The loop is O(s) per bill (time grows about linearly with s); the if-version is O(1) for a fixed number of tests but its code grows with every new slab. Extra space is O(s). **The loop is easier to change**: a new slab is one more table row, while the if-version needs new code and a new test case. At 3 slabs the if-version is about 30% faster, which is irrelevant next to input reading.

## Task 2 — Expectation vs execution (4 marks)
**Expectation:** floats and `int` would be fine for rupee totals. **Observed** (`Task02/output_compare.txt`, same pseudo-random units for every column):
| Bills | Exact total (paise) | float total (Rs) | float error | 32-bit int total |
|---|---|---|---|---|
| 4,000 | 329,950,325 | 3,299,503.25 | 0 | 329,950,325 ok |
| 60,000 | 4,930,858,425 | 49,306,984.00 | -160,025 paise (Rs 1,600) | 635,891,129 **OVERFLOW** |
| 800,000 | 65,443,345,150 | 655,441,152.00 | +100,770,050 paise (Rs 10.08 lakh) | 1,018,835,710 **OVERFLOW** |
- **Do float and paise versions agree?** Only at 4,000 bills (and then by luck of small values). At 60,000 and 800,000 they differ by Rs 1.6 thousand and Rs 10 lakh. A float has 24 mantissa bits, so it is exact only up to 16,777,216 paise = Rs 167,772.16 — less than one village's total.
- **Overflow:** `int` (32-bit here) overflows between 4,000 and 60,000 bills (limit 2,147,483,647 paise = Rs 2.14 crore). `long` and `long long` are exact at all three scales **on this system**.
- **sizeof vs standard minimum** (`output_limits.txt`): int 4 B here (standard guarantees only 16 bits, max 32767 paise = Rs 327.67 — less than one bad bill); long 8 B here (standard guarantees 32 bits, max Rs 2.14 crore — enough for a village but not a taluk or district); long long 8 B (standard guarantees 64 bits, max about Rs 9.2x10^16). Only `long long` is guaranteed to hold the district total on any conforming compiler.
- **Reason for differences:** the C standard only gives minimum sizes; the platform (LP64 Linux) chose 64-bit `long`. Windows chooses 32-bit `long`, where the district total would overflow. Floats fail because of limited precision; `int` fails because of limited range.
- Note: the `double` rupee total was exact here (error 0.0000 paise) because every rate is a multiple of 0.25, which a binary fraction represents exactly. Adding Rs 0.01 ten million times gives 99999.9999863 instead of 100000 (error -1.4e-5), so double is only accidentally safe.

**Alternative: accumulate the district total in `double`** (`output_precision.txt`, `output_bench_add.txt`):
| Type | Fails when | How it fails | Time per addition | Space |
|---|---|---|---|---|
| long long (paise) | total > 9.22e18 paise | **overflow**: sudden, wraps to a negative number | 0.375 ns | 8 B |
| double | whole-paise total > 2^53 = 9.0e15 (+1 is silently lost); any fractional rupee (0.01) is inexact from the first add | **precision loss**: gradual, small silent error | 2.21 ns | 8 B |
| float | total > 2^24 = 16,777,216 paise | precision loss | 2.18 ns | 4 B |
At 800,000 bills the total is 6.5x10^10 paise: far below both limits, so a `double` of **whole paise** is exact at 800,000 bills (confirmed: `double-of-paise = exact`), while a `double` of **rupees** is only exact by luck. Integer addition is also about 6x faster per dependent add here (1 cycle vs floating-point latency). Both are O(1) per addition and 8 bytes. Overflow is loud when detected (`__builtin_add_overflow`), precision loss is silent — a reason to prefer `long long`.

## Task 3 — Recommend and defend the final design (4 marks)
**Recommended types:** `long long` (or `int64_t`) for all money, in **paise**; `unsigned`/`long` for meter readings (0..65535, validated); no float/double in billing. Evidence: float wrong at 60,000 bills; int overflow at 60,000; long long exact at 800,000 and guaranteed 64-bit.
**Constants:** meter modulus, maximum plausible units, and data-type choices are **compile-time** (`#define` in one header) — they describe the hardware, not policy. **Tariff** values (fixed charge, slab limits, rates) go in a **configuration file** read at start-up (Task 4 needs this anyway). **Preprocessor features:** include guards; one header for constants/prototypes; `#ifdef DEBUG` for tracing (zero cost when off, Task 1 of the previous assignment).
**How a tariff revision is carried out:** edit `tariff.cfg` (example `tariff_v2.cfg`: fixed 6000, rates 250/500) and restart. Same executable, no recompile: units 150 changes from Rs 162.50 to Rs 185.00 (`output_config_demo.txt`). The loader refuses an invalid file (`tariff_bad.cfg`, limits out of order -> exit code 5, no bills printed), so a typo cannot corrupt bills.
**Limitations:** (1) a wrong but valid-looking file (for example a rate mistyped as 22.5 instead of 225) is accepted — the board should review/sign the file; (2) a table limited to `MAX_SLABS` entries; (3) rates are whole paise per unit; (4) 16-bit meter and 5000-unit plausibility limit are assumptions; (5) text parsing is not the fastest.
**Correct at district scale?** Yes: 800,000 bills = 6.5x10^10 paise, far below 9.2x10^18; tested exactly. Single-core time for 800,000 bills is well under a second (see Task 1: about 5-8 ns per bill).

**Alternative: tariff in a configuration file** (measured, `output_startup_time.txt`, `output_recompile_time.txt`):
| Number of tariff entries t | Start-up load time | Memory for table |
|---|---|---|
| 3 | 0.0034 ms | 48 B |
| 1,000 | 0.231 ms | 16 KB |
| 100,000 | 15.1 ms | 1.6 MB |
Load time is O(t) and space O(t), paid once per program start. Compiling the tariff in instead costs, for every revision: a recompile (about 102 ms measured for this tiny program; much more for a large one), re-testing and **redistributing** the 16 KB executable to every office. Start-up cost for any realistic tariff (a handful of slabs) is microseconds, so the config file wins decisively; the compile-time design wins only on having no file to get wrong.

## Task 4 — Day-4 design challenge: re-evaluate and adapt (8 marks)
**Changed requirement:** smart meters send Wh every 15 minutes (96 per day, 35,040 per house per year); units used 6 PM-10 PM cost 20% more; tariff changeable without recompiling.
**Assumptions:** each reading is the energy used in that 15-minute interval (Wh); slot 0 = 00:00-00:15, hour = slot/4, so slots 72-87 (18:00-21:59) are peak; the slab is decided by **cumulative units in the month** (chronological), and the 20% is added on top of whichever slab rate applies; 1 unit = 1 kWh = 1000 Wh. (If meters send a cumulative register instead, take differences with the same modulus logic as Task 1.)

**Decision: RETAIN, MODIFY, REDESIGN**
| Part of original design | Decision | Why |
|---|---|---|
| Integer arithmetic, no floats | **Retain** | Float failed at 60,000 bills (Task 2) |
| 64-bit totals; validation of every input; one header of constants | **Retain** | Proven correct and safe at district scale |
| Rollover logic (`METER_MODULUS`) | **Retain** (only for cumulative registers) | Interval readings do not roll over |
| Tariff as `#define` | **Modify** | Moves to a validated config file (Task 3): slab table, fixed charge, `peak_hours`, `peak_percent` |
| If-statements for 3 slabs | **Modify** | Slab-array loop (Task 1 alternative) — a new slab or time-band is data, not code |
| Bill from one monthly total (units = curr - prev) | **Redesign** | Peak vs off-peak depends on *when* energy was used, so the program must stream readings and accumulate cost per reading |
| Rounding per bill | **Redesign** | Cost kept as exact integers of 10^-5 paise (Wh x paise/kWh x percent) and **rounded once per bill**, half up |
| Read all houses then bill | **Redesign** | 2.3 billion readings/month at district scale: stream line by line, O(1) memory (one house's accumulators) |
So the verdict is **MODIFY the tariff and slab logic and REDESIGN the billing core and input pipeline**; the numeric foundations are retained.

**Implementation:** `smartbill.c`. For each reading: find hour, set multiplier 100 (+20 in peak), then take Wh from slabs in order, splitting a reading that straddles a slab boundary: `cost += take x rate x multiplier`. At end of house: `bill = fixed + (cost + 50000) / 100000`.
**Tests** (`output_tests.txt`; hand calculation vs program):
| House | Readings | Hand calculation | Program |
|---|---|---|---|
| 1 | 60 kWh + 60 kWh off-peak, 50 kWh at 18:00 | 20 kWh x 2.25 + 50 x 2.70 + 50 = 45 + 135 + 50 | Rs 230.00 |
| 2 | 90 kWh off-peak, 30 kWh peak (crosses 100 kWh) | 10 free + 20 x 2.70 + 50 | Rs 104.00 |
| 3 | 250 kWh in one peak reading (three slabs) | 100 free + 100 x 2.70 + 50 x 5.40 + 50 | Rs 590.00 |
| 4 | 100 kWh free, then 1 kWh at 17:45, 18:00, 21:45, 22:00 | 2.25 + 2.70 + 2.70 + 2.25 + 50 | Rs 59.90 |
Peak boundaries are correct (17:45 off-peak, 18:00 peak, 21:45 peak, 22:00 off-peak). Three invalid lines (`12x`, slot 96, negative Wh) are skipped and counted. With `tariff_v2.cfg` (rates 250/500, peak 25%, fixed Rs 60) the same executable gives different bills (house 1 = Rs 266.25), and `tariff_bad.cfg` is rejected. `oracle.py` recomputes every bill with exact fractions: all match for the test file and for 25 houses x 30 days (`output_oracle*.txt`).

**Scale** (`output_scale.txt`; 63 ns per reading measured, parse + billing, text input, one core):
| Scale | Houses | Readings per month (2,880/house) | Time per month (1 core) | Readings per year (35,040/house) | Binary storage per year (2 B/reading) |
|---|---|---|---|---|---|
| Village | 4,000 | 11.5 million | 0.7 s | 140 million | 0.28 GB |
| Taluk | 60,000 | 173 million | 10.9 s | 2.1 billion | 4.2 GB |
| District | 800,000 | 2.3 billion | 145 s (~2.4 min) | 28 billion | 56 GB |
Time is O(R) for R readings (each read once); memory O(1) (O(H) only if houses are not grouped). Houses are independent, so the district run can be split across cores or files. Binary input (`fread`) instead of text would be faster still; holding a year of readings in memory is not feasible at district scale.
**Limitations:** readings must be grouped by house and in time order; a missing interval is not detected; the peak window is whole hours; a reading above the 64-bit range is impossible in practice but values are only checked for non-negative, slot 0-95; time-zone or daylight-saving issues are not modelled.
