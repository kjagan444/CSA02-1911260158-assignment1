/* Task 03 alternative: tariff read from a configuration file at start-up.
   usage: cfg_bill tariff.cfg units.txt        -> bills
          cfg_bill tariff.cfg --bench R         -> average load time over R loads */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

typedef struct { long limit; long rate; } Slab;
#define MAX_SLABS 200000
static Slab slabs[MAX_SLABS];
static int  nslabs;
static long fixed_paise;

static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec*1e-9; }

/* returns 0 on success; validates so a typo cannot silently corrupt every bill */
static int load_tariff(const char *path)
{
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); return 1; }
    char line[128], lim[32]; long rate, v; nslabs = 0; fixed_paise = -1;
    while (fgets(line, sizeof line, f)) {
        if (sscanf(line, "fixed %ld", &v) == 1) fixed_paise = v;
        else if (sscanf(line, "slab %31s %ld", lim, &rate) == 2) {
            if (nslabs >= MAX_SLABS) { fclose(f); return 2; }
            slabs[nslabs].limit = strcmp(lim, "inf") == 0 ? LONG_MAX : atol(lim);
            slabs[nslabs].rate  = rate;
            nslabs++;
        }
    }
    fclose(f);
    if (fixed_paise < 0 || nslabs < 1 || slabs[nslabs-1].limit != LONG_MAX) return 3;
    for (int i = 0; i < nslabs; i++) {
        if (slabs[i].rate < 0) return 4;
        if (i && slabs[i].limit <= slabs[i-1].limit) return 5;   /* limits must increase */
    }
    return 0;
}

static long bill(long units)
{
    long energy = 0, lower = 0;
    for (int i = 0; i < nslabs && units > lower; i++) {
        long upper = slabs[i].limit;
        energy += ((units < upper ? units : upper) - lower) * slabs[i].rate;
        lower = upper;
    }
    return fixed_paise + energy;
}

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s tariff.cfg units.txt | --bench R\n", argv[0]); return 1; }
    if (strcmp(argv[2], "--bench") == 0) {
        int R = argc > 3 ? atoi(argv[3]) : 20, rc = 0;
        double t0 = now();
        for (int r = 0; r < R; r++) rc |= load_tariff(argv[1]);
        double ms = (now() - t0) / R * 1e3;
        printf("slabs=%d  load time=%.4f ms (avg of %d)  memory for table=%zu bytes  rc=%d\n",
               nslabs, ms, R, (size_t)nslabs * sizeof(Slab), rc);
        return rc;
    }
    double t0 = now();
    int rc = load_tariff(argv[1]);
    fprintf(stderr, "[tariff loaded: %d slabs, fixed %ld paise, %.4f ms, rc=%d]\n", nslabs, fixed_paise, (now()-t0)*1e3, rc);
    if (rc) { fprintf(stderr, "bad tariff file - refusing to bill\n"); return rc; }
    FILE *u = fopen(argv[2], "r"); if (!u) return 1;
    long units, total = 0;
    while (fscanf(u, "%ld", &units) == 1) {
        long b = bill(units); total += b;
        printf("%6ld units -> Rs %ld.%02ld\n", units, b/100, b%100);
    }
    printf("total Rs %ld.%02ld\n", total/100, total%100);
    fclose(u);
    return 0;
}
