# CSA02 Assignment 1 - Grama Jyothi Rural Electricity Co-operative Billing

**Name:** Jagan
**Register Number:** <your register number>
**Compiler:** gcc <your version> (output of `gcc --version`)

## Compile and run
Run these from inside each task folder.

| Task | Compile | Run |
|---|---|---|
| Task02 | `gcc -Wall -Wextra -o task02 task02.c` | `./task02` (Windows: `task02.exe`) |
| Task03 | `gcc -Wall -Wextra -o task03 task03.c` | `./task03` |
| Task04 | `gcc -Wall -Wextra -o task04 task04.c` | `./task04` |
| Task04 (macro expansion) | `gcc -E task04.c` | shows the preprocessed code |

## Folder structure
- Task01 - Problem analysis (written report)
- Task02 - Data types (16-bit rollover, sizes and limits, float vs paise)
- Task03 - Constants (slab-wise bill using macros)
- Task04 - Macros (SQUARE, MAX, inline functions)

## Results
- Task 1: Inputs, outputs, constants, rules and assumptions analysed in `Task01`.
- Task 2: Output matches expected; consumption after rollover is 256 (65400 -> 120 wraps modulo 65536). float total is wrong by Rs 120 over 4000 bills; long paise is exact.
- Task 3: Bills match expected (350 units -> Rs 950.00).
- Task 4: Macro pitfalls shown with `gcc -E`; `static inline` functions avoid them.
