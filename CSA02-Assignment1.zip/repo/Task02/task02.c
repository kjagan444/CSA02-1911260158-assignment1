#include <stdio.h>
#include <limits.h>
#include <float.h>

/* The meter register is a 16-bit counter: after 65535 it rolls over to 0. */
typedef unsigned short meter_t;

unsigned int consumption(meter_t previous, meter_t current)
{
    /* TODO 1 done: subtract, then cast back to 16 bits.
       The cast reduces the result modulo 65536, so a rollover
       (current < previous) is handled with no if-else. */
    return (meter_t)(current - previous);
}

int main(void)
{
    printf("sizeof(meter_t) = %zu bytes, maximum reading = %u\n",
           sizeof(meter_t), (unsigned)USHRT_MAX);
    printf("Consumption: %u units\n", consumption(1200, 1510));
    printf("Consumption: %u units\n", consumption(65400, 120)); /* rolled over */

    /* ---- Data type table (sizes and ranges on this system) ---- */
    printf("\n--- Data type sizes and limits ---\n");
    printf("char        : %zu byte,  %d to %d\n", sizeof(char), CHAR_MIN, CHAR_MAX);
    printf("short       : %zu bytes, %d to %d\n", sizeof(short), SHRT_MIN, SHRT_MAX);
    printf("unsigned short: %zu bytes, 0 to %u\n", sizeof(unsigned short), (unsigned)USHRT_MAX);
    printf("int         : %zu bytes, %d to %d\n", sizeof(int), INT_MIN, INT_MAX);
    printf("unsigned int: %zu bytes, 0 to %u\n", sizeof(unsigned int), UINT_MAX);
    printf("long        : %zu bytes, %ld to %ld\n", sizeof(long), LONG_MIN, LONG_MAX);
    printf("long long   : %zu bytes, %lld to %lld\n", sizeof(long long), LLONG_MIN, LLONG_MAX);
    printf("float       : %zu bytes, max %e, %d digits precision\n", sizeof(float), FLT_MAX, FLT_DIG);
    printf("double      : %zu bytes, max %e, %d digits precision\n", sizeof(double), DBL_MAX, DBL_DIG);

    /* ---- float versus long paise over 4000 bills ---- */
    printf("\n--- Adding 4000 bills of Rs 1234.57 ---\n");
    float  total_f = 0.0f;
    double total_d = 0.0;
    long   total_p = 0;                 /* paise: exact integers */
    for (int i = 0; i < 4000; i++) {
        total_f += 1234.57f;
        total_d += 1234.57;
        total_p += 123457L;
    }
    printf("float total : Rs %.2f\n", total_f);
    printf("double total: Rs %.2f\n", total_d);
    printf("paise total : Rs %ld.%02ld  (exact)\n", total_p / 100, total_p % 100);
    printf("True answer : Rs 4938280.00\n");
    return 0;
}
