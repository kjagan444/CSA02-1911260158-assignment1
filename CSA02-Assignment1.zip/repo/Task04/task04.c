#include <stdio.h>

/* Wrong macro: no parentheses */
#define SQUARE_BAD(x)  x*x
/* Correct macro: every parameter and the whole body in parentheses */
#define SQUARE(x)      ((x) * (x))

/* MAX evaluates its arguments twice: a hazard when they have side effects */
#define MAX(a, b)      ((a) > (b) ? (a) : (b))

/* Safer alternative: a static inline function evaluates each argument once */
static inline int max_inline(int a, int b) { return a > b ? a : b; }
static inline int square_inline(int x)     { return x * x; }

int main(void)
{
    int a = 3;
    printf("SQUARE_BAD(a+1) = %d   (expands to a+1*a+1 = 3+3+1 = 7, wrong)\n", SQUARE_BAD(a + 1));
    printf("SQUARE(a+1)     = %d   (expands to ((a+1)*(a+1)) = 16, correct)\n", SQUARE(a + 1));

    int i = 5, j = 3;
    int m = MAX(i++, j);   /* becomes ((i++) > (j) ? (i++) : (j)) */
    printf("MAX(i++, j)     = %d, i = %d   (wrong: i++ ran twice, so result should be 5 and i should be 6)\n", m, i);

    i = 5; j = 3;
    m = max_inline(i++, j);
    printf("max_inline(i++, j) = %d, i = %d   (argument evaluated once)\n", m, i);

    printf("square_inline(a+1) = %d\n", square_inline(a + 1));
    return 0;
}
